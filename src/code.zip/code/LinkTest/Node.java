package LinkTest;

public class Node{
	 public Node next; //ָ����  
     public  int data;//������  
       
     public Node( int data) {  
           this. data = data;  
     }  
       
     //��ʾ�˽ڵ�  
     public void display() {  
          System. out.print( data + " ");  
     }  
}
