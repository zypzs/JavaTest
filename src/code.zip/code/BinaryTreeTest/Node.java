package BinaryTreeTest;

public class Node {
	public int value;
	public Node left;
	public Node right;
	Node(int x){
		this.value=x;
	}

}
